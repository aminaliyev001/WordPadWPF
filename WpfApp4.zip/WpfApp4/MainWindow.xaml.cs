﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp4
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void OpenFile(object sender, RoutedEventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.Filter = "Text documents (.txt)|*.txt";
            if (dialog.ShowDialog() == true)
            {
                textbox.Text = File.ReadAllText(dialog.FileName);
                filename.Text = dialog.FileName;
                MessageBox.Show("File acildi");
            }
        }

        private void SaveF(object sender, RoutedEventArgs e)
        {
            SaveFileDialog save = new SaveFileDialog();
            save.Filter = "Text documents (.txt)|*.txt";
            if(save.ShowDialog() == true)
            {
                File.WriteAllText(save.FileName, textbox.Text);
                MessageBox.Show("Save olundu");
            }
        }

        private void textboxChanged(object sender, TextChangedEventArgs e)
        {
            if(checkb.IsChecked == true)
            {
                File.WriteAllText(filename.Text, textbox.Text);
            }
        }

        private void copyfunc(object sender, RoutedEventArgs e)
        {
            Clipboard.SetText(textbox.Text);
            MessageBox.Show("Clipboard-a copy olundu");
        }

        private void pastefunc(object sender, RoutedEventArgs e)
        {
            textbox.Paste();
        }
        private void selectfunc(object sender, RoutedEventArgs e)
        {
            textbox.SelectAll();
        }
        private void cutfunc(object sender, RoutedEventArgs e)
        {
            textbox.Cut();
        }
    }
}
